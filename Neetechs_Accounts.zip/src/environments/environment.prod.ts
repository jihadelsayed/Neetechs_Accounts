export const environment = {
  production: true,
  STRIPE_PUBLIC_KEY: "pk_test_51IwTvvIR19rXEZpRWoj9M4BGNy5nJ1GQOsXUZXHRD0PS3QGexQQSVNQR0vMB8jMoONQtO4RNQ30pC3N5BdgiGstB00shA8ejRI",
  SERVER_URL_WITH_OUT_SLASH: "",
 // FrontEnd_URL: window.location.origin,
  //CHAT_URL: "wss://server."+ window.location.hostname.replace(/^[^.]+./, '') +"/ws/chat/",
  //SERVER_URL: "https://server."+ window.location.hostname.replace(/^[^.]+./, '') +"/",
  //MainDomain: window.location.hostname.replace(/^[^.]+./, ''),
};
