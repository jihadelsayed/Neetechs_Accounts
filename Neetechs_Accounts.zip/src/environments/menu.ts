export const menu = [
  {
    id: 1,
    title: "ai",
    routerLink: "ai",
  },
]
