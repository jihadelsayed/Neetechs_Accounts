// ambient typings
